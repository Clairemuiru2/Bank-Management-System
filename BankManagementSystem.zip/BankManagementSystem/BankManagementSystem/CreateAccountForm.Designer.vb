﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CreateAccountForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        Label1 = New Label()
        Panel2 = New Panel()
        Panel17 = New Panel()
        Panel18 = New Panel()
        TextBox8 = New TextBox()
        Label10 = New Label()
        Panel15 = New Panel()
        Panel16 = New Panel()
        TextBox7 = New TextBox()
        Label9 = New Label()
        Panel13 = New Panel()
        Panel14 = New Panel()
        txtIdNumber = New TextBox()
        Label8 = New Label()
        Panel11 = New Panel()
        Panel12 = New Panel()
        txtAddress = New TextBox()
        Label7 = New Label()
        Panel9 = New Panel()
        Panel10 = New Panel()
        txtEmail = New TextBox()
        Label6 = New Label()
        Panel7 = New Panel()
        Panel8 = New Panel()
        txtAccountNumber = New TextBox()
        Label5 = New Label()
        Panel5 = New Panel()
        Panel6 = New Panel()
        txtPhone = New TextBox()
        Label3 = New Label()
        Panel3 = New Panel()
        Panel4 = New Panel()
        txtFullName = New TextBox()
        Label4 = New Label()
        Label2 = New Label()
        btnSaveCustomer = New Button()
        Button2 = New Button()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        Panel18.SuspendLayout()
        Panel16.SuspendLayout()
        Panel14.SuspendLayout()
        Panel12.SuspendLayout()
        Panel10.SuspendLayout()
        Panel8.SuspendLayout()
        Panel6.SuspendLayout()
        Panel4.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(0, 214, 50)
        Panel1.BorderStyle = BorderStyle.Fixed3D
        Panel1.Controls.Add(Label1)
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(502, 47)
        Panel1.TabIndex = 0
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Calibri", 18.0F, FontStyle.Bold, GraphicsUnit.Point, 0)
        Label1.ForeColor = Color.White
        Label1.Location = New Point(3, 7)
        Label1.Name = "Label1"
        Label1.Size = New Size(269, 29)
        Label1.TabIndex = 0
        Label1.Text = "Create Customer Account"
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.White
        Panel2.BorderStyle = BorderStyle.Fixed3D
        Panel2.Controls.Add(Panel17)
        Panel2.Controls.Add(Panel18)
        Panel2.Controls.Add(Label10)
        Panel2.Controls.Add(Panel15)
        Panel2.Controls.Add(Panel16)
        Panel2.Controls.Add(Label9)
        Panel2.Controls.Add(Panel13)
        Panel2.Controls.Add(Panel14)
        Panel2.Controls.Add(Label8)
        Panel2.Controls.Add(Panel11)
        Panel2.Controls.Add(Panel12)
        Panel2.Controls.Add(Label7)
        Panel2.Controls.Add(Panel9)
        Panel2.Controls.Add(Panel10)
        Panel2.Controls.Add(Label6)
        Panel2.Controls.Add(Panel7)
        Panel2.Controls.Add(Panel8)
        Panel2.Controls.Add(Label5)
        Panel2.Controls.Add(Panel5)
        Panel2.Controls.Add(Panel6)
        Panel2.Controls.Add(Label3)
        Panel2.Controls.Add(Panel3)
        Panel2.Controls.Add(Panel4)
        Panel2.Controls.Add(Label4)
        Panel2.Controls.Add(Label2)
        Panel2.Location = New Point(12, 63)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(576, 332)
        Panel2.TabIndex = 1
        ' 
        ' Panel17
        ' 
        Panel17.BackColor = Color.FromArgb(0, 214, 50)
        Panel17.Location = New Point(264, 317)
        Panel17.Name = "Panel17"
        Panel17.Size = New Size(181, 1)
        Panel17.TabIndex = 31
        ' 
        ' Panel18
        ' 
        Panel18.Controls.Add(TextBox8)
        Panel18.Location = New Point(264, 286)
        Panel18.Name = "Panel18"
        Panel18.Size = New Size(179, 40)
        Panel18.TabIndex = 30
        ' 
        ' TextBox8
        ' 
        TextBox8.BorderStyle = BorderStyle.None
        TextBox8.Font = New Font("Calibri", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
        TextBox8.Location = New Point(2, 10)
        TextBox8.Name = "TextBox8"
        TextBox8.Size = New Size(156, 16)
        TextBox8.TabIndex = 0
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Calibri", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
        Label10.Location = New Point(264, 272)
        Label10.Name = "Label10"
        Label10.Size = New Size(87, 15)
        Label10.TabIndex = 29
        Label10.Text = "Initial Balance"
        ' 
        ' Panel15
        ' 
        Panel15.BackColor = Color.FromArgb(0, 214, 50)
        Panel15.Location = New Point(13, 317)
        Panel15.Name = "Panel15"
        Panel15.Size = New Size(181, 1)
        Panel15.TabIndex = 28
        ' 
        ' Panel16
        ' 
        Panel16.Controls.Add(TextBox7)
        Panel16.Location = New Point(13, 286)
        Panel16.Name = "Panel16"
        Panel16.Size = New Size(179, 40)
        Panel16.TabIndex = 27
        ' 
        ' TextBox7
        ' 
        TextBox7.BorderStyle = BorderStyle.None
        TextBox7.Font = New Font("Calibri", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
        TextBox7.Location = New Point(2, 10)
        TextBox7.Name = "TextBox7"
        TextBox7.Size = New Size(156, 16)
        TextBox7.TabIndex = 0
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Calibri", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
        Label9.Location = New Point(13, 272)
        Label9.Name = "Label9"
        Label9.Size = New Size(80, 15)
        Label9.TabIndex = 26
        Label9.Text = "Customer Pin"
        ' 
        ' Panel13
        ' 
        Panel13.BackColor = Color.FromArgb(0, 214, 50)
        Panel13.Location = New Point(264, 250)
        Panel13.Name = "Panel13"
        Panel13.Size = New Size(181, 1)
        Panel13.TabIndex = 25
        ' 
        ' Panel14
        ' 
        Panel14.Controls.Add(txtIdNumber)
        Panel14.Location = New Point(264, 219)
        Panel14.Name = "Panel14"
        Panel14.Size = New Size(179, 40)
        Panel14.TabIndex = 24
        ' 
        ' txtIdNumber
        ' 
        txtIdNumber.BorderStyle = BorderStyle.None
        txtIdNumber.Font = New Font("Calibri", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
        txtIdNumber.Location = New Point(2, 10)
        txtIdNumber.Name = "txtIdNumber"
        txtIdNumber.Size = New Size(156, 16)
        txtIdNumber.TabIndex = 0
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Calibri", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
        Label8.Location = New Point(264, 205)
        Label8.Name = "Label8"
        Label8.Size = New Size(65, 15)
        Label8.TabIndex = 23
        Label8.Text = "ID Number"
        ' 
        ' Panel11
        ' 
        Panel11.BackColor = Color.FromArgb(0, 214, 50)
        Panel11.Location = New Point(13, 250)
        Panel11.Name = "Panel11"
        Panel11.Size = New Size(181, 1)
        Panel11.TabIndex = 22
        ' 
        ' Panel12
        ' 
        Panel12.Controls.Add(txtAddress)
        Panel12.Location = New Point(13, 219)
        Panel12.Name = "Panel12"
        Panel12.Size = New Size(179, 40)
        Panel12.TabIndex = 21
        ' 
        ' txtAddress
        ' 
        txtAddress.BorderStyle = BorderStyle.None
        txtAddress.Font = New Font("Calibri", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
        txtAddress.Location = New Point(2, 10)
        txtAddress.Name = "txtAddress"
        txtAddress.Size = New Size(156, 16)
        txtAddress.TabIndex = 0
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Calibri", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
        Label7.Location = New Point(13, 205)
        Label7.Name = "Label7"
        Label7.Size = New Size(51, 15)
        Label7.TabIndex = 20
        Label7.Text = "Address"
        ' 
        ' Panel9
        ' 
        Panel9.BackColor = Color.FromArgb(0, 214, 50)
        Panel9.Location = New Point(264, 172)
        Panel9.Name = "Panel9"
        Panel9.Size = New Size(181, 1)
        Panel9.TabIndex = 19
        ' 
        ' Panel10
        ' 
        Panel10.Controls.Add(txtEmail)
        Panel10.Location = New Point(264, 141)
        Panel10.Name = "Panel10"
        Panel10.Size = New Size(179, 40)
        Panel10.TabIndex = 18
        ' 
        ' txtEmail
        ' 
        txtEmail.BorderStyle = BorderStyle.None
        txtEmail.Font = New Font("Calibri", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
        txtEmail.Location = New Point(2, 10)
        txtEmail.Name = "txtEmail"
        txtEmail.Size = New Size(156, 16)
        txtEmail.TabIndex = 0
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Calibri", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
        Label6.Location = New Point(264, 127)
        Label6.Name = "Label6"
        Label6.Size = New Size(85, 15)
        Label6.TabIndex = 17
        Label6.Text = "Email Address"
        ' 
        ' Panel7
        ' 
        Panel7.BackColor = Color.FromArgb(0, 214, 50)
        Panel7.Location = New Point(264, 96)
        Panel7.Name = "Panel7"
        Panel7.Size = New Size(181, 1)
        Panel7.TabIndex = 16
        ' 
        ' Panel8
        ' 
        Panel8.Controls.Add(txtAccountNumber)
        Panel8.Location = New Point(264, 65)
        Panel8.Name = "Panel8"
        Panel8.Size = New Size(179, 40)
        Panel8.TabIndex = 15
        ' 
        ' txtAccountNumber
        ' 
        txtAccountNumber.BorderStyle = BorderStyle.None
        txtAccountNumber.Font = New Font("Calibri", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
        txtAccountNumber.Location = New Point(2, 10)
        txtAccountNumber.Name = "txtAccountNumber"
        txtAccountNumber.Size = New Size(156, 16)
        txtAccountNumber.TabIndex = 0
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Calibri", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
        Label5.Location = New Point(264, 51)
        Label5.Name = "Label5"
        Label5.Size = New Size(96, 15)
        Label5.TabIndex = 14
        Label5.Text = "Account number"
        ' 
        ' Panel5
        ' 
        Panel5.BackColor = Color.FromArgb(0, 214, 50)
        Panel5.Location = New Point(13, 172)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(181, 1)
        Panel5.TabIndex = 13
        ' 
        ' Panel6
        ' 
        Panel6.Controls.Add(txtPhone)
        Panel6.Location = New Point(13, 141)
        Panel6.Name = "Panel6"
        Panel6.Size = New Size(179, 40)
        Panel6.TabIndex = 12
        ' 
        ' txtPhone
        ' 
        txtPhone.BorderStyle = BorderStyle.None
        txtPhone.Font = New Font("Calibri", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
        txtPhone.Location = New Point(2, 10)
        txtPhone.Name = "txtPhone"
        txtPhone.Size = New Size(156, 16)
        txtPhone.TabIndex = 0
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Calibri", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
        Label3.Location = New Point(13, 127)
        Label3.Name = "Label3"
        Label3.Size = New Size(79, 15)
        Label3.TabIndex = 11
        Label3.Text = "Phone numer"
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.FromArgb(0, 214, 50)
        Panel3.Location = New Point(13, 96)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(181, 1)
        Panel3.TabIndex = 10
        ' 
        ' Panel4
        ' 
        Panel4.Controls.Add(txtFullName)
        Panel4.Location = New Point(13, 65)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(179, 40)
        Panel4.TabIndex = 9
        ' 
        ' txtFullName
        ' 
        txtFullName.BorderStyle = BorderStyle.None
        txtFullName.Font = New Font("Calibri", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
        txtFullName.Location = New Point(1, 10)
        txtFullName.Name = "txtFullName"
        txtFullName.Size = New Size(156, 16)
        txtFullName.TabIndex = 0
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Calibri", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
        Label4.Location = New Point(13, 51)
        Label4.Name = "Label4"
        Label4.Size = New Size(62, 15)
        Label4.TabIndex = 8
        Label4.Text = "Full Name"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Calibri", 12.0F, FontStyle.Bold, GraphicsUnit.Point, 0)
        Label2.Location = New Point(13, 10)
        Label2.Name = "Label2"
        Label2.Size = New Size(159, 19)
        Label2.TabIndex = 1
        Label2.Text = "Customer Information"
        ' 
        ' btnSaveCustomer
        ' 
        btnSaveCustomer.BackColor = Color.FromArgb(0, 214, 50)
        btnSaveCustomer.ForeColor = Color.White
        btnSaveCustomer.Location = New Point(371, 401)
        btnSaveCustomer.Name = "btnSaveCustomer"
        btnSaveCustomer.Size = New Size(105, 37)
        btnSaveCustomer.TabIndex = 2
        btnSaveCustomer.Text = "Create Account"
        btnSaveCustomer.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(501, 411)
        Button2.Name = "Button2"
        Button2.Size = New Size(105, 23)
        Button2.TabIndex = 3
        Button2.Text = "Cancel"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' CreateAccountForm
        ' 
        AutoScaleDimensions = New SizeF(7.0F, 15.0F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(600, 450)
        Controls.Add(Button2)
        Controls.Add(btnSaveCustomer)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        Name = "CreateAccountForm"
        Text = "CreateAccountForm"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel18.ResumeLayout(False)
        Panel18.PerformLayout()
        Panel16.ResumeLayout(False)
        Panel16.PerformLayout()
        Panel14.ResumeLayout(False)
        Panel14.PerformLayout()
        Panel12.ResumeLayout(False)
        Panel12.PerformLayout()
        Panel10.ResumeLayout(False)
        Panel10.PerformLayout()
        Panel8.ResumeLayout(False)
        Panel8.PerformLayout()
        Panel6.ResumeLayout(False)
        Panel6.PerformLayout()
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents btnSaveCustomer As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents txtFullName As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel17 As Panel
    Friend WithEvents Panel18 As Panel
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Panel15 As Panel
    Friend WithEvents Panel16 As Panel
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Panel14 As Panel
    Friend WithEvents txtIdNumber As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Panel12 As Panel
    Friend WithEvents txtAddress As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Panel10 As Panel
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents txtAccountNumber As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents txtPhone As TextBox
    Friend WithEvents Label3 As Label
End Class
